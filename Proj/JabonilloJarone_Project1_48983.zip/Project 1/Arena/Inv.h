/* 
 * File:   Inv.h
 * Author: Kauru99
 *
 * Created on October 21, 2015, 11:30 AM
 */

#ifndef INV_H
#define	INV_H

struct Inv{
    int max; //Maximum cap
    int cap; //Allowed capacity
    int size; //number of items
    int *stck; //pointer of items
};

#endif	/* INV_H */

