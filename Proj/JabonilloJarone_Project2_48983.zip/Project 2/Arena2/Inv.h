/* 
 * File:   Inv.h
 * Author: Kauru99
 *
 * Created on December 12, 2015, 9:20 PM
 */

#ifndef INV_H
#define	INV_H

//Templated class
template<class T>
//Inventory structure
struct Inv{
    T max; //Maximum cap
    T cap; //Allowed capacity
    T size; //Number of items
    T *stck; //Pointer of items
};


#endif	/* INV_H */

