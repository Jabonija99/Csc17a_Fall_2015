/* 
 * File:   Game.cpp
 * Author: Kauru99
 * 
 * Created on December 11, 2015, 10:04 PM
 */


#include <string>
#include <fstream>
#include <iostream>

#include "Game.h"
#include "Player.h"

using namespace std;

Game::Game(){
    //Set initial game completion and checkpoint values
    gCmplte = 0;
    gChckpt = 1;
}

void Game::modCmplte(int val){
    //Increment completion % by the given value
    gCmplte += val;
}
void Game::setChckpt(int val){
    //Set checkpoint to indicated value
    gChckpt = val;
}

bool Game::save(Player user){
    //Error checker
    bool error = true;
    //Create game save under the player name
    gFlNme = "deps/Saves/" + user.gtName() + ".dat";
    
    //Try to open the file
    try{
        //Opens a file to write, binary enabled, truncates contents
        gFile.open(gFlNme.c_str(), ios::out | ios::binary | ios::trunc);
        
        //If file fails to open
        if(!gFile){
            //Throw an exception
            throw -1;
        }
        
        //Writes the character in the binary file
        gFile.write(reinterpret_cast<char *> (&user), sizeof(user));
    
    //Catch any errors
    }catch(...){
        //Set error to false
        error = false;
    }
    
    //Close the file
    gFile.close();
    
    //Create game save for game progress
    gFlNme = "deps/Saves/" + user.gtName() + "_game.dat";
    
    //Try to open the file
    try{
        //Opens a file to write, truncates contents
        gFile.open(gFlNme.c_str(), ios::out | ios::trunc);
        
        //If file fails to open
        if(!gFile){
            //Throw an exception
            throw -1;
        }
        
        //Writes completion % and checkpoint
        gFile << gCmplte <<endl
                <<gChckpt <<endl;
    
    //Catch any errors
    }catch(...){
        //Set error to false
        error = false;
    }
    
    //Close the file
    gFile.close();
    
    //Returns error status
    return error;
}
bool Game::load(Player&user, string name){
    //Error checking flag
    bool error = true;
    
    //File name
    gFlNme = "deps/Saves/" + name + ".dat";
    
    //Try to open the file
    try{
        //Open a read file with binary enabled
        gFile.open(gFlNme.c_str(), ios::in | ios::binary);
        
        //If the file fails to open
        if(!gFile){
            //Throw an exception
            throw -1;
        }
        
        //Loads the saved Player to the player object
        gFile.read(reinterpret_cast<char *>(&user), sizeof(user));
    
    //If it catches any exceptions
    }catch(...){
        //Flag error
        error = false;
    }
    
    //Close the file
    gFile.close();
    
    //File name
    gFlNme = "deps/Saves/" + name + "_game.dat";
    
    //Try to open the file
    try{
        //Open a read file
        gFile.open(gFlNme.c_str(), ios::in);
        
        //If the file fails to open
        if(!gFile){
            //Throw an exception
            throw -1;
        }
        
         //Read completion % and checkpoint
        gFile >> gCmplte;
        gFile >> gChckpt;
    
    //If it catches any exceptions
    }catch(...){
        //Flag error
        error = false;
    }
    
    //Close the file
    gFile.close();
    
    //Return error status
    return error;
}

int Game::getCmplte(){
    //Return game complete percentage
    return gCmplte;
}
int Game::getChckpt(){
    //Return game checkpoint
    return gChckpt;
}


